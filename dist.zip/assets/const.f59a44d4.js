function W(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}function Z(e){var a=e.default;if(typeof a=="function"){var t=function(){return a.apply(this,arguments)};t.prototype=a.prototype}else t={};return Object.defineProperty(t,"__esModule",{value:!0}),Object.keys(e).forEach(function(u){var r=Object.getOwnPropertyDescriptor(e,u);Object.defineProperty(t,u,r.get?r:{enumerable:!0,get:function(){return e[u]}})}),t}const l="bilibili-subtitle",T="bilibili-subtitle-iframe",_="bilibili-subtitle_env",A="bilibili-subtitle_temp",i="translate",s="summarize_overview",o="summarize_keypoint",n="summarize_brief",p=[{name:"\u7FFB\u8BD1",type:i},{name:"\u6982\u89C8",type:s},{name:"\u8981\u70B9",type:o},{name:"\u603B\u7ED3",type:n}],d={brief:{name:"\u603B\u7ED3",desc:"\u4E00\u53E5\u8BDD\u603B\u7ED3",downloadName:"\u{1F4A1}\u89C6\u9891\u603B\u7ED3\u{1F4A1}",promptType:n},overview:{name:"\u6982\u89C8",desc:"\u53EF\u5B9A\u4F4D\u5230\u89C6\u9891\u4F4D\u7F6E",downloadName:"\u{1F4A1}\u89C6\u9891\u6982\u89C8\u{1F4A1}",promptType:s},keypoint:{name:"\u8981\u70B9",desc:"\u5B8C\u6574\u7684\u8981\u70B9\u63D0\u53D6",downloadName:"\u{1F4A1}\u89C6\u9891\u8981\u70B9\u{1F4A1}",promptType:o}},b={[i]:`You are a professional translator. Translate following video subtitles to language '{{language}}'.
Preserve incomplete sentence.
Translate in the same json format.
Answer in markdown json format.

video subtitles:

\`\`\`
{{subtitles}}
\`\`\``,[s]:`You are a helpful assistant that summarize key points of video subtitle.
Summarize 3 to 8 brief key points in language '{{language}}'.
Answer in markdown json format.
The emoji should be related to the key point and 1 char length.

example output format:

\`\`\`json
[
  {
    "time": "03:00",
    "emoji": "\u{1F44D}",
    "key": "key point 1"
  },
  {
    "time": "10:05",
    "emoji": "\u{1F60A}",
    "key": "key point 2"
  }
]
\`\`\`

The video's title: '''{{title}}'''.
The video's subtitles:

'''
{{subtitles}}
'''`,[o]:`You are a helpful assistant that summarize key points of video subtitle.
Summarize brief key points in language '{{language}}'.
Answer in markdown json format.

example output format:

\`\`\`json
[
  "key point 1",
  "key point 2"
]
\`\`\`

The video's title: '''{{title}}'''.
The video's subtitles:

'''
{{segment}}
'''`,[n]:`You are a helpful assistant that summarize video subtitle.
Summarize in language '{{language}}'.
Answer in markdown json format.

example output format:

\`\`\`json
{
  "summary": "brief summary"
}
\`\`\`

The video's title: '''{{title}}'''.
The video's subtitles:

'''
{{segment}}
'''`},g="expand",f=15*60*1e3,S="main",R="settings",D=5*1e3,P=15,M=5,y=25,O=5,F="en",h=400,I=520,L=800,N=44,v=24,k=2e3,H=500,j=16e3,G=500,U=100,w="cn",B=5,C="https://api.openai.com",z="https://op.kongkongye.com",c=[{code:"gpt-3.5-turbo",name:"gpt-3.5-turbo"},{code:"gpt-3.5-turbo-16k",name:"gpt-3.5-turbo-16k"}],Y=c[0].code,E=[{code:"en",name:"English"},{code:"ena",name:"American English"},{code:"enb",name:"British English"},{code:"cn",name:"\u4E2D\u6587\u7B80\u4F53"},{code:"cnt",name:"\u4E2D\u6587\u7E41\u4F53"},{code:"Spanish",name:"espa\xF1ol"},{code:"French",name:"Fran\xE7ais"},{code:"Arabic",name:"\u0627\u0644\u0639\u0631\u0628\u064A\u0629"},{code:"Russian",name:"\u0440\u0443\u0441\u0441\u043A\u0438\u0439"},{code:"German",name:"Deutsch"},{code:"Portuguese",name:"Portugu\xEAs"},{code:"Italian",name:"Italiano"}],m={};for(const e of E)m[e.code]=e;const x=Object.freeze(Object.defineProperty({__proto__:null,APP_DOM_ID:l,IFRAME_ID:T,STORAGE_ENV:_,STORAGE_TEMP:A,PROMPT_TYPE_TRANSLATE:i,PROMPT_TYPE_SUMMARIZE_OVERVIEW:s,PROMPT_TYPE_SUMMARIZE_KEYPOINT:o,PROMPT_TYPE_SUMMARIZE_BRIEF:n,PROMPT_TYPES:p,SUMMARIZE_TYPES:d,PROMPT_DEFAULTS:b,EVENT_EXPAND:g,TASK_EXPIRE_TIME:f,PAGE_MAIN:S,PAGE_SETTINGS:R,TRANSLATE_COOLDOWN:D,TRANSLATE_FETCH_DEFAULT:P,TRANSLATE_FETCH_MIN:M,TRANSLATE_FETCH_MAX:y,TRANSLATE_FETCH_STEP:O,LANGUAGE_DEFAULT:F,TOTAL_HEIGHT_MIN:h,TOTAL_HEIGHT_DEF:I,TOTAL_HEIGHT_MAX:L,HEADER_HEIGHT:N,TITLE_HEIGHT:v,WORDS_DEFAULT:k,WORDS_MIN:H,WORDS_MAX:j,WORDS_STEP:G,SUMMARIZE_THRESHOLD:U,SUMMARIZE_LANGUAGE_DEFAULT:w,SUMMARIZE_ALL_THRESHOLD:B,SERVER_URL_OPENAI:C,SERVER_URL_THIRD:z,MODELS:c,MODEL_DEFAULT:Y,LANGUAGES:E,LANGUAGES_MAP:m},Symbol.toStringTag,{value:"Module"}));export{l as A,A as B,g as E,N as H,m as L,Y as M,R as P,d as S,f as T,k as W,x as _,W as a,C as b,I as c,F as d,w as e,D as f,Z as g,P as h,i,b as j,U as k,S as l,B as m,v as n,h as o,L as p,H as q,j as r,y as s,O as t,z as u,c as v,p as w,E as x,M as y,_ as z};
