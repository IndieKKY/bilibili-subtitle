(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/content-script.cjs.6a7fca44.js")
    );
  })().catch(console.error);

})();
